package com.Pokemon;

/**
 * Created by DAM on 5/10/16.
 */
public interface Capturable {
    public boolean capturar();
}
