package com.Lambdas.Zoo;

import com.Lambdas.Zoo.Animal;

@FunctionalInterface
public interface checkAtribut {
    public void check(Animal a);
}
