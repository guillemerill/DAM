package com.Lambdas.EjemploLambdas;

@FunctionalInterface
public interface IReadNumero {
    public Integer readNumber();
}
