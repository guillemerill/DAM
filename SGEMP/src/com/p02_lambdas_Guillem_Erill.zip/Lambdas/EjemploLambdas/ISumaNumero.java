package com.Lambdas.EjemploLambdas;

@FunctionalInterface
public interface ISumaNumero {
    public int sumaNumbers(int num1, int num2);
}
