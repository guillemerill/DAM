package com.Lambdas.EjemploLambdas;

@FunctionalInterface
public interface ITallaString {
    public String tallaString(String palabra);
}
