package com.Lambdas.LOL;

@FunctionalInterface
public interface checkEstadistica {
    public boolean check(ObjetoLOL obj);
}
